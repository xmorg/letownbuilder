
package net.cooperlabs.letownbuilder;

import org.love2d.android.GameActivity;

public class TownActivity extends GameActivity {
}
